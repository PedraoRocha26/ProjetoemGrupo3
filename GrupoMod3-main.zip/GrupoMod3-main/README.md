
# Projeto Tech Store

Olá, quero apresentar a vocês o projeto Tech Store, um website de ecommerce desenvolvido em grupo, utilizando React JS.

![foto sobre o site tech store](https://user-images.githubusercontent.com/100978478/203310202-0230d7da-502a-4022-a320-69d6e0830606.png)

Para ver o projeto hospedado e rodando [clique aqui](https://grupo-mod3.vercel.app/)
